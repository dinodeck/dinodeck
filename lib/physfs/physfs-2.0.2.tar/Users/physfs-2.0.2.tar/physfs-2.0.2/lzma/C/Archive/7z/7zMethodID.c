/* 7zMethodID.c */

#include "7zMethodID.h"

/*
int AreMethodsEqual(CMethodID *a1, CMethodID *a2)
{
  return (*a1 == *a2) ? 1 : 0;
}
*/
